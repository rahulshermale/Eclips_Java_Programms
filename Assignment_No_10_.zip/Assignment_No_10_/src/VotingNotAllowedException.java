
public class VotingNotAllowedException extends Exception {

}
